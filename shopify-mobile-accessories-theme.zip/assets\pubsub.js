/**
 * PubSub - Simple publish/subscribe pattern for theme events
 */

class PubSub {
  constructor() {
    this.events = {};
  }

  subscribe(event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);

    // Return unsubscribe function
    return () => {
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    };
  }

  publish(event, data) {
    if (this.events[event]) {
      this.events[event].forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in PubSub event ${event}:`, error);
        }
      });
    }
  }

  once(event, callback) {
    const unsubscribe = this.subscribe(event, (data) => {
      callback(data);
      unsubscribe();
    });
    return unsubscribe;
  }
}

// Create global instance
window.PubSub = new PubSub();

// Common theme events
window.THEME_EVENTS = {
  CART_UPDATED: 'cart:updated',
  CART_OPENED: 'cart:opened',
  CART_CLOSED: 'cart:closed',
  VARIANT_CHANGED: 'variant:changed',
  PRODUCT_ADDED: 'product:added',
  SEARCH_OPENED: 'search:opened',
  SEARCH_CLOSED: 'search:closed',
  QUICK_VIEW_OPENED: 'quickview:opened',
  QUICK_VIEW_CLOSED: 'quickview:closed'
};