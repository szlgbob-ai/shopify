/**
 * Constants for the theme
 */

const THEME_CONSTANTS = {
  CART: {
    ADD_URL: window.theme?.routes?.cart_add_url || '/cart/add',
    CHANGE_URL: window.theme?.routes?.cart_change_url || '/cart/change',
    UPDATE_URL: window.theme?.routes?.cart_update_url || '/cart/update',
    URL: window.theme?.routes?.cart_url || '/cart'
  },
  PREDICTIVE_SEARCH_URL: window.theme?.routes?.predictive_search_url || '/search/suggest',
  BREAKPOINTS: {
    mobile: 768,
    tablet: 990,
    desktop: 1200
  }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = THEME_CONSTANTS;
}