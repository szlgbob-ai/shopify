/**
 * Global theme JavaScript
 */

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', function() {
  initHeader();
  initCartDrawer();
  initMobileMenu();
});

/**
 * Header functionality
 */
function initHeader() {
  const header = document.querySelector('.header');
  if (!header) return;

  // Sticky header shadow on scroll
  let lastScroll = 0;
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
      header.classList.add('header--scrolled');
    } else {
      header.classList.remove('header--scrolled');
    }
    
    lastScroll = currentScroll;
  }, { passive: true });
}

/**
 * Cart Drawer functionality
 */
function initCartDrawer() {
  const cartDrawer = document.getElementById('CartDrawer');
  const cartOverlay = document.querySelector('.drawer-overlay');
  const cartIcon = document.querySelector('.header__icon--cart');
  
  if (!cartDrawer) return;

  // Open cart drawer
  if (cartIcon) {
    cartIcon.addEventListener('click', (e) => {
      if (window.theme?.settings?.cart_type === 'drawer') {
        e.preventDefault();
        openCartDrawer();
      }
    });
  }

  // Close cart drawer
  const closeButton = cartDrawer.querySelector('.js-drawer-close');
  if (closeButton) {
    closeButton.addEventListener('click', closeCartDrawer);
  }

  if (cartOverlay) {
    cartOverlay.addEventListener('click', closeCartDrawer);
  }

  // Close on escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && cartDrawer.classList.contains('drawer--open')) {
      closeCartDrawer();
    }
  });

  function openCartDrawer() {
    cartDrawer.classList.add('drawer--open');
    if (cartOverlay) cartOverlay.classList.add('is-visible');
    document.body.classList.add('drawer-open');
    
    // Publish event
    if (window.PubSub) {
      window.PubSub.publish(window.THEME_EVENTS?.CART_OPENED || 'cart:opened');
    }
  }

  function closeCartDrawer() {
    cartDrawer.classList.remove('drawer--open');
    if (cartOverlay) cartOverlay.classList.remove('is-visible');
    document.body.classList.remove('drawer-open');
    
    // Publish event
    if (window.PubSub) {
      window.PubSub.publish(window.THEME_EVENTS?.CART_CLOSED || 'cart:closed');
    }
  }
}

/**
 * Mobile Menu functionality
 */
function initMobileMenu() {
  const menuToggle = document.querySelector('.header__menu-toggle');
  const nav = document.querySelector('.header__nav');
  
  if (!menuToggle || !nav) return;

  menuToggle.addEventListener('click', () => {
    nav.classList.toggle('is-open');
    menuToggle.classList.toggle('is-active');
    document.body.classList.toggle('menu-open');
  });
}

/**
 * Cart API helpers
 */
window.CartAPI = {
  addItem: async function(formData) {
    try {
      const response = await fetch(THEME_CONSTANTS?.CART?.ADD_URL || '/cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      
      if (!response.ok) throw new Error('Failed to add item');
      
      const data = await response.json();
      
      // Update cart and publish event
      await this.getCart();
      
      if (window.PubSub) {
        window.PubSub.publish(window.THEME_EVENTS?.PRODUCT_ADDED || 'product:added', data);
      }
      
      return data;
    } catch (error) {
      console.error('Cart add error:', error);
      throw error;
    }
  },

  updateItem: async function(line, quantity) {
    try {
      const response = await fetch(THEME_CONSTANTS?.CART?.CHANGE_URL || '/cart/change.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ line, quantity })
      });
      
      if (!response.ok) throw new Error('Failed to update item');
      
      const data = await response.json();
      await this.getCart();
      
      return data;
    } catch (error) {
      console.error('Cart update error:', error);
      throw error;
    }
  },

  getCart: async function() {
    try {
      const response = await fetch(THEME_CONSTANTS?.CART?.URL + '.js' || '/cart.js');
      const cart = await response.json();
      
      // Update global cart object
      if (window.theme) {
        window.theme.cart = cart;
      }
      
      // Publish event
      if (window.PubSub) {
        window.PubSub.publish(window.THEME_EVENTS?.CART_UPDATED || 'cart:updated', cart);
      }
      
      // Update cart count
      updateCartCount(cart.item_count);
      
      return cart;
    } catch (error) {
      console.error('Get cart error:', error);
      throw error;
    }
  }
};

/**
 * Update cart count in header
 */
function updateCartCount(count) {
  const cartCountElements = document.querySelectorAll('.header__cart-count');
  cartCountElements.forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

/**
 * Debounce utility
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Throttle utility
 */
function throttle(func, limit) {
  let inThrottle;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}